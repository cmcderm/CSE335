heilcha1: Charles Heil

Contributions:
Charles Heil:
readme.txt
print functions
setup
Visitor Pattern
debugging


mcderm60: Connor McDermott

Contributions:
UML Chart;
editting
Visitor Pattern
copy constructor;
